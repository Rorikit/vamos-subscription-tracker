# Model Contract: State Model

Purpose: render entity lifecycles and valid transitions.

Required snapshot sections:

- `entities`
- `states`
- `transitions`
- `business_rules`

Required fields:

- State: `id`, `entity`, `value`, `name_ru`
- Transition: `id`, `entity`, `from`, `to`, `trigger`, `business_rule`

Validation:

- state belongs to exactly one entity;
- transition cannot cross entity state machines;
- transition trigger should be tied to a rule or product action.
