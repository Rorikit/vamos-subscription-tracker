# Model Contract: Domain Model

Purpose: render domain entities, fields and semantic relationships.

Required snapshot sections:

- `entities`
- `relationships`
- `business_rules`

Required fields:

- Entity: `id`, `name_ru`, `module`, `fields`, `relationships`
- Relationship: `id`, `from`, `to`, `type`, `cardinality`

Validation:

- every relationship endpoint must be an existing entity;
- every entity module must exist;
- business rules may reference entities but must not redefine persistence.
